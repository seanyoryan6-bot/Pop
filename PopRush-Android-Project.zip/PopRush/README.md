# Pop Rush
A self-contained portrait Android arcade game.

## Gameplay
Pop normal balloons, collect gold balloons, avoid bombs, and use hearts to restore lives. Difficulty increases over time. High score persists locally.

## Build
Open this folder in Android Studio, allow Gradle sync, then Run on an Android device/emulator.
For Google Play: Build > Generate Signed App Bundle / APK > Android App Bundle.

Package: ie.poprush.game
Version: 1.0.0 (1)
Minimum Android: 7.0 / API 24
Target SDK: 35

Before publishing, add final launcher/store artwork, privacy/data-safety declarations, screenshots, signing key, and complete Play Console testing/release requirements.
