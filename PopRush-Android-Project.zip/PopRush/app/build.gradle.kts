plugins { id("com.android.application") }

android {
    namespace = "ie.poprush.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "ie.poprush.game"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
