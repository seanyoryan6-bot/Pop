package ie.poprush.game

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class GameView(context: Context) : View(context) {
    private enum class State { MENU, PLAYING, PAUSED, GAME_OVER }
    private enum class Kind { NORMAL, GOLD, BOMB, HEART }
    private data class Balloon(var x:Float,var y:Float,var r:Float,var speed:Float,val kind:Kind,val color:Int,var wobble:Float=0f)
    private data class Particle(var x:Float,var y:Float,var vx:Float,var vy:Float,var life:Float,val color:Int)

    private val paint=Paint(Paint.ANTI_ALIAS_FLAG); private val text=Paint(Paint.ANTI_ALIAS_FLAG)
    private val balloons=mutableListOf<Balloon>(); private val particles=mutableListOf<Particle>()
    private var state=State.MENU; private var score=0; private var lives=3; private var combo=0; private var best=context.getSharedPreferences("poprush",0).getInt("best",0)
    private var last=SystemClock.elapsedRealtime(); private var spawn=0f; private var elapsed=0f
    private val colors=intArrayOf(Color.rgb(255,77,109),Color.rgb(92,130,255),Color.rgb(137,220,91),Color.rgb(187,105,255),Color.rgb(255,143,66))

    init { isFocusable=true; text.typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD) }
    private fun dp(v:Float)=v*resources.displayMetrics.density
    private fun start(){balloons.clear();particles.clear();score=0;lives=3;combo=0;elapsed=0f;spawn=.25f;state=State.PLAYING;last=SystemClock.elapsedRealtime();invalidate()}
    override fun onDraw(c:Canvas){super.onDraw(c); val now=SystemClock.elapsedRealtime(); val dt=((now-last)/1000f).coerceIn(0f,.04f);last=now;if(state==State.PLAYING)update(dt);drawSky(c);drawGame(c);if(state!=State.PLAYING)drawOverlay(c);if(state==State.PLAYING)postInvalidateOnAnimation()}
    private fun drawSky(c:Canvas){val g=LinearGradient(0f,0f,0f,height.toFloat(),Color.rgb(100,198,255),Color.rgb(221,247,255),Shader.TileMode.CLAMP);paint.shader=g;c.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint);paint.shader=null;paint.color=Color.argb(120,255,255,255);for(i in 0..5){val y=height*(.12f+i*.15f);val x=((i*173)%max(1,width)).toFloat();c.drawCircle(x,y,dp(28f),paint);c.drawCircle(x+dp(27f),y+dp(4f),dp(21f),paint)}}
    private fun drawGame(c:Canvas){for(b in balloons)drawBalloon(c,b);for(p in particles){paint.color=p.color;paint.alpha=(255*p.life.coerceIn(0f,1f)).toInt();c.drawCircle(p.x,p.y,dp(3.5f),paint)}paint.alpha=255;text.color=Color.WHITE;text.textSize=dp(24f);text.setShadowLayer(dp(3f),0f,dp(2f),Color.argb(100,0,0,0));c.drawText("$score",dp(18f),dp(38f),text);text.textSize=dp(16f);c.drawText("BEST $best",dp(18f),dp(61f),text);c.drawText("❤ $lives",width-dp(72f),dp(38f),text);if(combo>=3){text.textSize=dp(20f);c.drawText("${combo}x COMBO",width/2f-dp(55f),dp(42f),text)}text.clearShadowLayer();if(state==State.PLAYING){paint.color=Color.argb(125,255,255,255);c.drawCircle(width-dp(30f),dp(72f),dp(19f),paint);paint.color=Color.rgb(70,90,110);c.drawRect(width-dp(37f),dp(63f),width-dp(32f),dp(81f),paint);c.drawRect(width-dp(27f),dp(63f),width-dp(22f),dp(81f),paint)}}
    private fun drawBalloon(c:Canvas,b:Balloon){paint.color=when(b.kind){Kind.GOLD->Color.rgb(255,195,25);Kind.BOMB->Color.rgb(48,52,60);Kind.HEART->Color.rgb(255,80,120);else->b.color};paint.style=Paint.Style.FILL;c.drawOval(b.x-b.r,b.y-b.r*1.18f,b.x+b.r,b.y+b.r*1.18f,paint);paint.color=Color.argb(90,255,255,255);c.drawOval(b.x-b.r*.48f,b.y-b.r*.72f,b.x-b.r*.12f,b.y-b.r*.25f,paint);paint.color=Color.rgb(90,90,100);paint.strokeWidth=dp(1.3f);c.drawLine(b.x,b.y+b.r*1.15f,b.x+sin(b.wobble)*dp(8f),b.y+b.r*1.8f,paint);text.textAlign=Paint.Align.CENTER;text.textSize=b.r*.8f;text.color=Color.WHITE;if(b.kind==Kind.BOMB)c.drawText("✹",b.x,b.y+b.r*.25f,text);if(b.kind==Kind.GOLD)c.drawText("★",b.x,b.y+b.r*.25f,text);if(b.kind==Kind.HEART)c.drawText("♥",b.x,b.y+b.r*.25f,text);text.textAlign=Paint.Align.LEFT}
    private fun update(dt:Float){elapsed+=dt;spawn-=dt;val difficulty=1f+(elapsed/35f).coerceAtMost(2.3f);if(spawn<=0f){spawn=(.72f/difficulty).coerceAtLeast(.22f);spawnBalloon(difficulty)};val it=balloons.iterator();while(it.hasNext()){val b=it.next();b.y-=b.speed*dt;b.wobble+=dt*4f;if(b.y+b.r<0){if(b.kind==Kind.NORMAL||b.kind==Kind.GOLD){lives--;combo=0};it.remove();if(lives<=0){gameOver();break}}};val pit=particles.iterator();while(pit.hasNext()){val p=pit.next();p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=dp(180f)*dt;p.life-=dt*1.8f;if(p.life<=0)pit.remove()}}
    private fun spawnBalloon(d:Float){val r=dp(Random.nextInt(24,34).toFloat());val roll=Random.nextInt(100);val kind=when{roll<7->Kind.BOMB;roll<13->Kind.GOLD;roll<16&&lives<3->Kind.HEART;else->Kind.NORMAL};balloons+=Balloon(Random.nextFloat()*(width-2*r)+r,height+r*2,r,dp(Random.nextInt(105,145).toFloat())*d,kind,colors.random())}
    private fun pop(b:Balloon){when(b.kind){Kind.BOMB->{lives--;combo=0};Kind.GOLD->{score+=5;combo++};Kind.HEART->{lives=(lives+1).coerceAtMost(3);score++;combo++};Kind.NORMAL->{score++;combo++}};if(combo>0&&combo%10==0)score+=3;repeat(12){val a=Random.nextFloat()*PI.toFloat()*2;val s=dp(Random.nextInt(50,150).toFloat());particles+=Particle(b.x,b.y,cos(a)*s,sin(a)*s,1f,if(b.kind==Kind.BOMB)Color.DKGRAY else b.color)};balloons.remove(b);if(lives<=0)gameOver()}
    private fun gameOver(){state=State.GAME_OVER;if(score>best){best=score;context.getSharedPreferences("poprush",0).edit().putInt("best",best).apply()}invalidate()}
    private fun drawOverlay(c:Canvas){paint.color=Color.argb(135,20,40,65);c.drawRect(0f,0f,width.toFloat(),height.toFloat(),paint);text.textAlign=Paint.Align.CENTER;text.color=Color.WHITE;text.setShadowLayer(dp(4f),0f,dp(2f),Color.argb(120,0,0,0));text.textSize=dp(42f);val title=when(state){State.MENU->"POP RUSH";State.PAUSED->"PAUSED";else->"GAME OVER"};c.drawText(title,width/2f,height*.39f,text);text.textSize=dp(18f);val sub=when(state){State.MENU->"Pop balloons. Avoid bombs.";State.PAUSED->"Tap below to keep popping";else->"Score $score  •  Best $best"};c.drawText(sub,width/2f,height*.45f,text);paint.color=Color.WHITE;paint.setShadowLayer(dp(5f),0f,dp(2f),Color.argb(80,0,0,0));val l=width*.2f;val r=width*.8f;val t=height*.51f;val bot=t+dp(58f);c.drawRoundRect(l,t,r,bot,dp(29f),dp(29f),paint);paint.clearShadowLayer();text.clearShadowLayer();text.color=Color.rgb(255,77,109);text.textSize=dp(20f);val button=when(state){State.MENU->"PLAY";State.PAUSED->"RESUME";else->"PLAY AGAIN"};c.drawText(button,width/2f,t+dp(37f),text);text.textAlign=Paint.Align.LEFT}
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_DOWN)return true;val x=e.x;val y=e.y;if(state==State.PLAYING){if(x>width-dp(60f)&&y<dp(110f)){state=State.PAUSED;invalidate();return true};val hit=balloons.asReversed().firstOrNull{hypot(x-it.x,y-it.y)<it.r*1.35f};if(hit!=null)pop(hit);invalidate()}else{val t=height*.49f;val bot=height*.51f+dp(70f);if(y in t..bot){if(state==State.PAUSED){state=State.PLAYING;last=SystemClock.elapsedRealtime();invalidate()}else start()}};return true}
}
